Files in this directory are copied verbatim from the
https://github.com/rust-lang/regex repository and are used for generating test
data. They do not become part of the proptest binary.
